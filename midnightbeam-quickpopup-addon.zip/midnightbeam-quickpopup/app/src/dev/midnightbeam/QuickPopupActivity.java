package dev.midnightbeam;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Build;
import android.widget.Toast;

/** Lightweight launcher target for Stickman. Does not replace or navigate to the main TV UI. */
public final class QuickPopupActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        try {
            Intent popup = new Intent(this, QuickPopupService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(popup);
            else startService(popup);
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't show MidnightBeam Quick: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
        finish();
        overridePendingTransition(0, 0);
    }
}
