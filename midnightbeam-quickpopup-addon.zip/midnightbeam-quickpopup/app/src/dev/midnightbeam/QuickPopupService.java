package dev.midnightbeam;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Fire-TV friendly floating quick settings. This class is meant to be added to MidnightBeam
 * itself, not installed as a separate app: DimService is protected by android.permission.DUMP.
 * All preset data is local to the TV. No network permissions are used by this feature.
 */
public final class QuickPopupService extends Service {
    private static final String CHANNEL = "midnightbeam_quick_popup";
    private static final int NOTIFICATION_ID = 10117;
    private static final String PREFS = "midnightbeam_quick_popup";
    private static final String PRESETS = "presets_v1";
    private static final int BG = 0xff1c1714;
    private static final int PANEL = 0xff30261e;
    private static final int GOLD = 0xffe0b474;
    private static final int PALE = 0xfffae9d2;
    private static final int GREY = 0xffb8a99a;
    private WindowManager wm;
    private View window;
    private LinearLayout presetRow;
    private EditText nameField;
    private SeekBar darknessBar, redBar, temperatureBar;
    private TextView darknessLabel, redLabel, temperatureLabel, statusLabel;
    private JSONArray presets;
    private int selected = -1;
    private boolean binding;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(new NotificationChannel(CHANNEL, "MidnightBeam quick controls", NotificationManager.IMPORTANCE_MIN));
            Notification notification = new Notification.Builder(this, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_menu_manage)
                    .setContentTitle("MidnightBeam quick controls")
                    .setContentText("Popup is open")
                    .setOngoing(true).build();
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (window != null) { dismiss(); return START_NOT_STICKY; } // repeated shortcut toggles it
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant MidnightBeam Display over other apps first", Toast.LENGTH_LONG).show();
            stopSelf();
            return START_NOT_STICKY;
        }
        loadPresets();
        try { showPopup(); } catch (Exception e) {
            Toast.makeText(this, "Popup error: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            dismiss();
        }
        return START_NOT_STICKY;
    }

    private void showPopup() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int width = Math.min(dp(740), getResources().getDisplayMetrics().widthPixels - dp(60));
        int height = Math.min(dp(760), getResources().getDisplayMetrics().heightPixels - dp(50));
        LinearLayout panel = new LinearLayout(this) {
            @Override public boolean dispatchKeyEvent(KeyEvent event) {
                if (event.getKeyCode() == KeyEvent.KEYCODE_BACK || event.getKeyCode() == KeyEvent.KEYCODE_ESCAPE) {
                    if (event.getAction() == KeyEvent.ACTION_UP) dismiss();
                    return true;
                }
                return super.dispatchKeyEvent(event);
            }
        };
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(24), dp(20), dp(24), dp(20));
        panel.setBackground(background(BG, 20, GOLD));
        panel.setFocusableInTouchMode(true);
        panel.setElevation(dp(16));

        ScrollView outerScroll = new ScrollView(this);
        outerScroll.setFillViewport(false);
        outerScroll.addView(panel);

        LinearLayout titleRow = horizontal();
        TextView heading = text("MIDNIGHTBEAM  •  QUICK CONTROLS", 20, PALE, true);
        titleRow.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        Button close = button("✕ Close", () -> dismiss());
        titleRow.addView(close);
        panel.addView(titleRow);
        panel.addView(space(18));
        panel.addView(text("PRESETS  ·  Press OK to apply", 14, GOLD, true));
        panel.addView(space(6));
        HorizontalScrollView horizontal = new HorizontalScrollView(this);
        horizontal.setHorizontalScrollBarEnabled(false);
        presetRow = horizontal();
        horizontal.addView(presetRow);
        panel.addView(horizontal);
        panel.addView(space(14));

        darknessLabel = text("Darkness", 17, PALE, true);
        darknessBar = slider(panel, darknessLabel, 95, 30);
        redLabel = text("Warm colour overlay", 17, PALE, true);
        redBar = slider(panel, redLabel, 100, 25);
        temperatureLabel = text("Colour temperature", 17, PALE, true);
        temperatureBar = slider(panel, temperatureLabel, 100, toTemperatureSlider(3000));
        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                updateLabels();
                if (fromUser && !binding) { applyCurrent(); status("Custom setting applied"); }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        };
        darknessBar.setOnSeekBarChangeListener(listener);
        redBar.setOnSeekBarChangeListener(listener);
        temperatureBar.setOnSeekBarChangeListener(listener);
        updateLabels();

        panel.addView(space(8));
        panel.addView(text("PRESET NAME", 14, GOLD, true));
        nameField = new EditText(this);
        nameField.setSingleLine(true);
        nameField.setSelectAllOnFocus(true);
        nameField.setHint("e.g. Wind Down");
        nameField.setTextColor(PALE);
        nameField.setHintTextColor(GREY);
        nameField.setTextSize(18);
        nameField.setPadding(dp(10), dp(8), dp(10), dp(8));
        nameField.setBackground(background(PANEL, 9, 0xff72543b));
        panel.addView(nameField);
        panel.addView(space(10));
        LinearLayout actions = horizontal();
        actions.addView(button("+ Save new", () -> savePreset(false)), new LinearLayout.LayoutParams(0, -2, 1));
        actions.addView(button("Update / Rename", () -> savePreset(true)), new LinearLayout.LayoutParams(0, -2, 1));
        actions.addView(button("Delete", this::deleteSelected), new LinearLayout.LayoutParams(0, -2, 0.75f));
        panel.addView(actions);
        panel.addView(space(12));
        LinearLayout footer = horizontal();
        footer.addView(button("Filter off", this::turnOff), new LinearLayout.LayoutParams(0, -2, 1));
        footer.addView(button("Apply & close", () -> { applyCurrent(); dismiss(); }), new LinearLayout.LayoutParams(0, -2, 1));
        panel.addView(footer);
        statusLabel = text("D-pad to navigate · Left/Right to adjust · Back to close", 13, GREY, false);
        panel.addView(space(10));
        panel.addView(statusLabel);

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                width, height, type,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.CENTER;
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        window = outerScroll;
        wm.addView(window, params);
        rebuildPresetButtons();
        close.requestFocus();
    }

    private void loadPresets() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        try { presets = new JSONArray(prefs.getString(PRESETS, "")); }
        catch (Exception e) { presets = new JSONArray(); }
        if (presets.length() == 0) {
            presets.put(record("Evening", 30, 25, 3000));
            presets.put(record("Wind Down", 65, 55, 1800));
            presets.put(record("Sleep", 85, 85, 1200));
            persist();
        }
    }

    private JSONObject record(String name, int darkness, int red, int temp) {
        JSONObject obj = new JSONObject();
        try {
            obj.put("name", name); obj.put("darkness", darkness);
            obj.put("red", red); obj.put("temp", temp);
        } catch (JSONException ignored) { }
        return obj;
    }

    private void rebuildPresetButtons() {
        if (presetRow == null) return;
        presetRow.removeAllViews();
        for (int i = 0; i < presets.length(); i++) {
            final int index = i;
            JSONObject obj = presets.optJSONObject(i);
            if (obj == null) continue;
            String name = obj.optString("name", "Preset");
            Button b = button((i == selected ? "● " : "☾ ") + name, () -> applyPreset(index));
            presetRow.addView(b);
        }
    }

    private void applyPreset(int index) {
        JSONObject p = presets.optJSONObject(index);
        if (p == null) return;
        selected = index;
        binding = true;
        darknessBar.setProgress(p.optInt("darkness", 30));
        redBar.setProgress(p.optInt("red", 25));
        temperatureBar.setProgress(toTemperatureSlider(p.optInt("temp", 3000)));
        nameField.setText(p.optString("name", "Preset"));
        binding = false;
        updateLabels();
        applyCurrent();
        status("Applied: " + p.optString("name", "Preset"));
        rebuildPresetButtons();
    }

    private void savePreset(boolean update) {
        String name = nameField.getText().toString().trim();
        if (name.isEmpty()) { status("Enter a preset name first"); nameField.requestFocus(); return; }
        if (name.length() > 32) name = name.substring(0, 32);
        JSONObject newValue = record(name, darknessBar.getProgress(), redBar.getProgress(), toTemp(temperatureBar.getProgress()));
        if (update && selected >= 0 && selected < presets.length()) {
            try { presets.put(selected, newValue); } catch (JSONException ignored) { }
        } else {
            int match = -1;
            for (int i = 0; i < presets.length(); i++) {
                JSONObject p = presets.optJSONObject(i);
                if (p != null && name.equalsIgnoreCase(p.optString("name"))) { match = i; break; }
            }
            if (match >= 0) {
                try { presets.put(match, newValue); } catch (JSONException ignored) { }
                selected = match;
            } else {
                if (presets.length() >= 24) { status("Maximum 24 presets"); return; }
                presets.put(newValue);
                selected = presets.length() - 1;
            }
        }
        persist();
        rebuildPresetButtons();
        status("Saved: " + name);
        hideKeyboard();
    }

    private void deleteSelected() {
        if (selected < 0 || selected >= presets.length()) { status("Select a preset to delete"); return; }
        String name = presets.optJSONObject(selected).optString("name", "Preset");
        JSONArray kept = new JSONArray();
        for (int i = 0; i < presets.length(); i++) if (i != selected) kept.put(presets.opt(i));
        presets = kept;
        selected = -1;
        nameField.setText("");
        persist();
        rebuildPresetButtons();
        status("Deleted: " + name);
    }

    private void persist() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PRESETS, presets.toString()).apply();
    }

    private void applyCurrent() {
        // Intent originates within the same application, satisfying DimService's DUMP protection.
        Intent update = new Intent();
        update.setClassName(getPackageName(), getPackageName() + ".DimService");
        update.putExtra("red", redBar.getProgress());
        update.putExtra("bright", 100 - darknessBar.getProgress());
        update.putExtra("temp", toTemp(temperatureBar.getProgress()));
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(update);
            else startService(update);
        } catch (Exception e) { status("Can't apply filter: " + e.getClass().getSimpleName()); }
    }

    private void turnOff() {
        Intent off = new Intent();
        off.setClassName(getPackageName(), getPackageName() + ".DimService");
        off.putExtra("off", true);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(off);
            else startService(off);
        } catch (Exception e) { status("Can't disable filter: " + e.getClass().getSimpleName()); }
        dismiss();
    }

    private void updateLabels() {
        if (darknessLabel == null || redLabel == null || temperatureLabel == null) return;
        darknessLabel.setText("Darkness     " + darknessBar.getProgress() + "%");
        redLabel.setText("Warm colour overlay     " + redBar.getProgress() + "%");
        temperatureLabel.setText("Colour temperature     " + toTemp(temperatureBar.getProgress()) + " K");
    }

    private int toTemp(int slider) { return 6500 - 55 * slider; }
    private int toTemperatureSlider(int temp) { return Math.max(0, Math.min(100, (6500 - temp + 27) / 55)); }
    private void status(String message) { if (statusLabel != null) statusLabel.setText(message); }

    private SeekBar slider(LinearLayout parent, TextView label, int max, int initial) {
        parent.addView(space(10));
        parent.addView(label);
        SeekBar slider = new SeekBar(this);
        slider.setMax(max);
        slider.setProgress(initial);
        parent.addView(slider);
        return slider;
    }

    private Button button(String label, Runnable callback) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(PALE);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setFocusable(true);
        b.setBackground(background(PANEL, 10, 0xff65513e));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(47));
        params.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(params);
        b.setOnFocusChangeListener((view, focused) -> {
            b.setBackground(background(focused ? 0xff60482f : PANEL, 10, focused ? GOLD : 0xff65513e));
            b.setTextColor(focused ? 0xffffffff : PALE);
        });
        b.setOnClickListener(v -> callback.run());
        return b;
    }
    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private View space(int hDp) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(hDp))); return v; }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable background(int color, float cornerDp, int border) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(cornerDp));
        if (border != 0) d.setStroke(dp(1), border);
        return d;
    }
    private int dp(float px) { return Math.round(px * getResources().getDisplayMetrics().density); }
    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null && window != null) imm.hideSoftInputFromWindow(window.getWindowToken(), 0);
    }
    private void dismiss() {
        if (window != null && wm != null) {
            try { wm.removeViewImmediate(window); } catch (Exception ignored) { }
            window = null;
        }
        stopForeground(true);
        stopSelf();
    }
    @Override public void onDestroy() { if (window != null && wm != null) { try { wm.removeViewImmediate(window); } catch (Exception ignored) { } window = null; } super.onDestroy(); }
}
